# GridWorld
A simple gridworld for studying Q-learning</br></br>
package used:</br>
numpy 1.14.4</br>
pillow 5.1.0</br></br>
code from https://github.com/rlcode/reinforcement-learning.git</br>

